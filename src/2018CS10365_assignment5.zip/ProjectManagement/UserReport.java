/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectManagement;

/**
 *
 * @author piyus
 */
public class UserReport implements UserReport_{
        
    public String Name;
    int consumption=0;
     public String user()
    {
        return Name;
    }
    public int consumed() 
    {
        return consumption;
    }
    
}
