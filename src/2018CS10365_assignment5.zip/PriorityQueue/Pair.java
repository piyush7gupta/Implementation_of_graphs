/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PriorityQueue;

/**
 *
 * @author piyus
 */
public class Pair<T> {
    T first;
    int second;
    
    public Pair(T one,int two)
    {
        first=one;
        second=two;
    }
    
}
